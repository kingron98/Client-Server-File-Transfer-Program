#include <sys/socket.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <pwd.h>
#include <grp.h>

#define LENGTH 512
#define NUM_THREADS 100

pthread_mutex_t lock;

void *connection_handler(void *);

int main() {
  int socket_desc;
  int client_sock;
  int conSize;
  int READSIZE;

  pthread_t client_conn[NUM_THREADS];
  struct sockaddr_in server, client;

  // char message[500];

  // create socket
  socket_desc = socket(AF_INET, SOCK_STREAM, 0);
  if (socket_desc == -1)
  {
    printf("Could not create socket\n");
  }
  else
  {
    printf("Socket successfully created!!\n");
  }

  // set sockaddr_in variables
  server.sin_port = htons(8801);
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;

  // bind
  if (bind(socket_desc, (struct sockaddr *)&server, sizeof(server)) < 0)
  {
    perror("Bind issue\n");
    return 1;
  }
  else
  {
    printf("Bind complete\n");
  }

  // listen for a connection
  listen(socket_desc, 3);

  // accept any incoming connection
  printf("Waiting for incoming connection from client\n");
  conSize = sizeof(struct sockaddr_in);
  pthread_t tid;
  int thread_count = 0;

  // mutex lock
  pthread_mutex_init(&lock, NULL);

  while ((client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t *)&conSize)))
  {
    puts("-Connection accepted\n");
    if (pthread_create(&client_conn[thread_count], NULL, connection_handler, (void *)&client_sock) < 0)
    {
      perror("could not create thread");
      return 1;
    }

    puts("*handler assigned for client connection\n");
    pthread_join(client_conn[thread_count], NULL);

    thread_count++;
  }

  if (client_sock < 0)
  {
    perror("accept failed");
    return 1;
  }

  return 0;
}

void *connection_handler(void *socket_desc)
{
  // get the socket descriptor
  int sock = *(int *)socket_desc;
  int uid = 0;

  char msg[500];
  int READSIZE;
  char *message, client_message[2000];
  char path[20];

  // reset msg
  memset(msg, 0, 500);

  // read message from the client
  READSIZE = recv(sock, msg, 500, 0);

  // if the client requested to transfer
  if (strcmp(msg, "initTransfer") == 0)
  {
    printf("-Init Transfer\n");
    write(sock, "user", strlen("user"));
  }
  // reset msg
  memset(msg, 0, 500);

  // read the next message
  READSIZE = recv(sock, msg, 500, 0);

  // if the client requested to transfer
  if (strcmp(msg, "initTransfer") != 0 && strlen(msg) > 0)
  {
    printf("*user: %s\n", msg);
    uid = atoi(msg);
    write(sock, "path", strlen("path"));
    //memset(msg, 0, 500);
  }
  // reset msg
  memset(msg, 0, 500);

  // read the next message
  READSIZE = recv(sock, msg, 500, 0);

  // if msg is not previous and contains new msg
  if (strcmp(msg, "initTransfer") != 0 && strlen(msg) > 0)
  {
    printf("*path: %s\n", msg);
    strcpy(path, msg);
    strcat(path, "/");
    write(sock, "file", strlen("file"));
  }
  // reset msg 
  memset(msg, 0, 500);

  // read the next message
  READSIZE = recv(sock, msg, 500, 0);
  
  // if msg is not previous and contains new msg
  if (strcmp(msg, "initTransfer") != 0 && strlen(msg) > 0)
  {
    // receive file from client
    char *fr_path = "/home/aaron/Documents/Assignment2/server_folder/";
    char revbuf[LENGTH];
    char *fr_name = (char *)malloc(1 + strlen(fr_path) + strlen(msg) + strlen(path));

    // strcat(fr_path, path);
    strcpy(fr_name, fr_path);
    strcat(fr_name, path);
    strcat(fr_name, msg);

    // permission 
    gid_t supp_groups[] = {};
    int j, ngroups;
    gid_t *groups;
    struct passwd *pw;
    pw = getpwuid(uid);
    struct group *gr;

    char *user_name = pw -> pw_name;

    ngroups = 10;
    groups = malloc(ngroups * sizeof(gid_t));

    if (getgrouplist(user_name, uid, groups, &ngroups) == -1) {
      printf("error\n");
      exit(1);
    }
    printf("*client is associated with groups\n");
    for(j = 0; j < ngroups; ++j) { 
      supp_groups[j] = groups[j];
      printf("-%d", supp_groups[j]);
    }

    // swap root to user
    setgroups(10, supp_groups);
    seteuid(uid);

    printf("\n-File\n");
    write(sock, "begin", strlen("begin"));
    printf("-Filename: %s\n", msg);
    
    // lock thread before file transfer
    pthread_mutex_lock(&lock);

    FILE *fr = fopen(fr_name, "w");
    if (fr == NULL)
    {
      printf("*file %s cannot be opened in the server\n", fr_name);
      printf("*user does not have permission\n");
    }
    else
    {
      bzero(revbuf, LENGTH);
      int fr_block_sz = 0;
      int i = 0;

      while ((fr_block_sz = recv(sock, revbuf, LENGTH, 0)) > 0)
      {
        printf("-Data received %d = %d\n", i, fr_block_sz);
        int write_sz = fwrite(revbuf, sizeof(char), fr_block_sz, fr);

        if (write_sz < fr_block_sz)
        {
          perror("-File write failed on the server\n");
        }

        bzero(revbuf, LENGTH);
        i++;
      }

      if (fr_block_sz < 0)
      {
        if (errno == EAGAIN)
        {
          printf("recv() timed out\n");
        }
      }
      
      printf("-Ok received from the client\n");
      fclose(fr);
    }

    // swap user back to root
    uid = 0;
    seteuid(uid);

    // sleep to demonstrate multithreading
    sleep(10);

    // unlock thread
    pthread_mutex_unlock(&lock);
  }
  
  // reset msg
  memset(msg, 0, 500);
  if (READSIZE == 0)
  {
    puts("Client disconnected");
    fflush(stdout);
  }
  else if (READSIZE == -1)
  {
    perror("recv() failed");
  }

  return 0;
}
