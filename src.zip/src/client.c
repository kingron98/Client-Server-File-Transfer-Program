#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

#define LENGTH 512

int main(int argc, char *argv[]) { 

	// command lind argument checking
	if(argc < 3) {
		printf("missing filename or path\n");
		return 1;
	}
	
	int SID;
	struct sockaddr_in server;
	char clientMessage[500];
	char serverMessage[500];	
	char *filename = argv[1];
	char *pathname = argv[2];

	// get the current user id
	uid_t uid = getuid();
	char *userid = malloc(sizeof(uid));
	sprintf(userid, "%d", uid);

	// create socket
	SID = socket(AF_INET, SOCK_STREAM, 0);

	if(SID == -1) { 
		printf("*error creating socket\n");
	} else { 
		printf("*socket created\n");
	}

	server.sin_port = htons (8801);
	server.sin_addr.s_addr = inet_addr("127.0.0.1");
	server.sin_family = AF_INET;

	// connect to server
	if(connect(SID, (struct  sockaddr*)&server, sizeof(server)) < 0 ) { 
		printf("connect failed. Error\n");
		return 1;
	}

	printf("-Connected to the server ok\n");

	// send init transfer message to the server
	if( send(SID, "initTransfer", strlen("initTransfer"), 0) < 0) {
		printf("send failed\n");
		return 1;
	}

	int len;
	// receive reply from the server
	if( (len = recv(SID, serverMessage, strlen("user"), 0)) < 0) { 
		printf("IO error\n");
	}

	serverMessage[len] = '\0';
	printf("*server sent %s\n", serverMessage);	

	if(strcmp(serverMessage, "user") == 0 ) { 
		printf("-Sending user %d\n", uid);

		if( send(SID, userid, strlen(userid), 0) < 0 ) { 
			printf("send failed\n");
			return 1;
		}
	} 

	// reset server message
	memset(serverMessage, 0, 500);
	// receive reply from the server
	if( recv(SID, serverMessage, 500, 0) < 0) { 
		printf("IO error\n");
	}

	serverMessage[len] = '\0';
	printf("*server sent %s\n", serverMessage);	
	// printf(serverMessage);

	if(strcmp(serverMessage, "path") == 0 ) { 
		printf("-Sending path %s\n", pathname);

		if( send(SID, pathname, strlen(pathname), 0) < 0 ) { 
			printf("send failed\n");
			return 1;
		}
	} 

	memset(serverMessage, 0, 500);
	// receive reply from the server
	if( recv(SID, serverMessage, 500, 0) < 0) { 
		printf("IO error\n");
	}

	serverMessage[len] = '\0';
	printf("*server sent %s\n", serverMessage);

	if(strcmp(serverMessage, "file") == 0 ) { 
		printf("-Sending file %s\n", filename);

		if( send(SID, filename, strlen(filename), 0) < 0 ) { 
			printf("send failed\n");
			return 1;
		}
	} 

	memset(serverMessage, 0, 500);
	// receive reply from the server
	if( recv(SID, serverMessage, 500, 0) < 0) { 
		printf("IO error\n");
	}

	printf("-Server sent %s of length %d\n", serverMessage, strlen(serverMessage) );
	if( strcmp(serverMessage, "begin") == 0 ) {
		printf("*sending file %s\n", filename);

		char *fs_path = "/home/aaron/Documents/Assignment2/client_folder/";
		char *fs_name = (char * ) malloc( 1 + strlen(fs_path) + strlen(filename) );
		
		strcpy(fs_name, fs_path);
		strcat(fs_name, filename);

		char sdbuf[LENGTH];
		
		printf("-Client sending %s to server ...\n", fs_name);

		FILE *fs = fopen(fs_name, "r");
		if(fs == NULL) { 
			printf("Error: %s, file not found\n", fs_name);
			return 1;
		}

		bzero(sdbuf, LENGTH);

		int fs_block_sz, i = 0;

		while( (fs_block_sz = fread(sdbuf, sizeof(char), LENGTH, fs)) > 0 ) {
			printf("-Data sent %d = %d\n", i , fs_block_sz);
			if( send(SID, sdbuf, fs_block_sz, 0) < 0) { 
				fprintf(stderr, "Error: failed to send file %s, errorno: %d\n", fs_name, errno);
				exit(1);
			}

			bzero(sdbuf, LENGTH);
			++i;
		}
	}
	
	close(SID);
	return 0;
}





